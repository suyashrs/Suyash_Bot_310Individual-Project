package cosc310Bot;


import net.dv8tion.jda.api.JDABuilder;



public class Main {
	public static JDABuilder jda;
	
	public static void main(String [] args) throws Exception{
		try {
			JDABuilder jda = JDABuilder.createDefault("OTQ2NTU3NjM5ODg4ODc1NTIx.Yhgcfw.6Kzs_yp10XfeVixiNOZXK4ntasA");
			jda.addEventListeners(new MyEventListener());
			jda.build();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
}
